// ============================================================
// TCS Private Limited — Order Management Web App
// Google Apps Script Backend (API Mode)
// ============================================================

var SPREADSHEET_ID = "1vcGDDTBy0zrUUj62bxbxEqj0Y_0n0ubnvcMrttnpW24";
var LOG_SHEET_NAME = "Activity Log";

// Pakistan timezone — is se sahi time aayega
var TZ = "Asia/Karachi";

// ============================================================
// ACTIVITY LOG
// ============================================================
function writeLog(ss, userName, action, detail) {
  // ss parameter ignore karo — apna khud banao (Web App mein safe hai)
  var _ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  var logSheet = _ss.getSheetByName(LOG_SHEET_NAME);
  if (!logSheet) {
    logSheet = _ss.insertSheet(LOG_SHEET_NAME);
    logSheet.getRange("A1:E1")
      .setValues([["Timestamp", "User Name", "Action", "Detail", "Session"]])
      .setFontWeight("bold")
      .setBackground("#1F3864")
      .setFontColor("#FFFFFF");
    logSheet.setColumnWidth(1, 160);
    logSheet.setColumnWidth(2, 140);
    logSheet.setColumnWidth(3, 160);
    logSheet.setColumnWidth(4, 400);
    logSheet.setColumnWidth(5, 180);
    // Freeze header
    logSheet.setFrozenRows(1);
    // Horizontal align
    logSheet.getRange("A1:E1").setHorizontalAlignment("center");
  }
  // Pakistan time
  var now = new Date();
  var timeStr = Utilities.formatDate(now, TZ, "dd-MMM-yyyy HH:mm:ss");
  // Session.getActiveUser() Web App anonymous mode mein error deta hai — userName hi use karo
  var sessionInfo = userName || "Unknown";
  logSheet.appendRow([timeStr, userName || "Unknown", action, detail || "", sessionInfo]);
  // Align data row
  var lastRow = logSheet.getLastRow();
  logSheet.getRange(lastRow, 1, 1, 5).setHorizontalAlignment("left");
}

// ============================================================
// WEB APP ENTRY POINT
// ============================================================
function doGet(e) {
  return HtmlService.createHtmlOutput("TCS API is running ✅");
}

function doPost(e) {
  var params = JSON.parse(e.postData.contents);
  var action = params.action;
  var result = {};

  try {
    if      (action === "getMasterData")         result = getMasterData();
    else if (action === "addMasterRow")          result = addMasterRow(params.data, params.userName);
    else if (action === "deleteMasterRow")       result = deleteMasterRow(params.rowIndex, params.userName);
    else if (action === "updateMasterRow")       result = updateMasterRow(params.rowIndex, params.data, params.userName);
    else if (action === "getRateFile")           result = getRateFile();
    else if (action === "getItemByCode")         result = getItemByCode(params.code, params.date, params.currentRow);
    else if (action === "generateSummary")       result = generateSummaryData(params.vendorCode, params.dateFrom, params.dateTo);
    else if (action === "generateVendorSlip")    result = generateVendorSlipData(params.vendorCode, params.dateFrom, params.dateTo);
    else if (action === "generateVendorDetails") result = generateVendorDetailsData(params.dateFrom, params.dateTo);
    else if (action === "generateRequisition")   result = generateRequisitionData(params.vendorCode, params.dateFrom, params.dateTo);
    else if (action === "getVendorList")         result = getVendorList();
    else if (action === "getActivityLog")        result = getActivityLog(params.dateFrom, params.dateTo, params.userName);
    else result = { success: false, error: "Unknown action: " + action };
  } catch (err) {
    result = { success: false, error: err.toString() };
  }

  return ContentService.createTextOutput(JSON.stringify(result))
    .setMimeType(ContentService.MimeType.JSON);
}

// ============================================================
// HELPERS
// ============================================================
function normalizeDate(d) {
  if (!d) return null;
  if (!(d instanceof Date)) d = new Date(d);
  if (isNaN(d.getTime())) return null;
  return new Date(d.getFullYear(), d.getMonth(), d.getDate());
}

function dateToStr(d) {
  if (!d) return "";
  return Utilities.formatDate(d, TZ, "dd-MMM-yyyy");
}

// ============================================================
// FORMAT MASTER SHEET — header + alignment
// ============================================================
function formatMasterSheet(master) {
  // Header row styling
  var header = master.getRange(1, 1, 1, 7);
  header.setValues([["SE GOF #", "Item Code(s)", "Item Desc(s)", "Date", "Box Desc(s)", "Qty", "Vendor Code(s)"]]);
  header.setFontWeight("bold");
  header.setBackground("#1F3864");
  header.setFontColor("#FFFFFF");
  header.setHorizontalAlignment("center");

  // Column widths
  master.setColumnWidth(1, 130);
  master.setColumnWidth(2, 120);
  master.setColumnWidth(3, 200);
  master.setColumnWidth(4, 110);
  master.setColumnWidth(5, 160);
  master.setColumnWidth(6, 60);
  master.setColumnWidth(7, 100);

  // Freeze header
  master.setFrozenRows(1);
}

// ============================================================
// GET MASTER DATA
// ============================================================
function getMasterData() {
  var ss     = SpreadsheetApp.openById(SPREADSHEET_ID);
  var master = ss.getSheetByName("Master Sheet");
  if (!master) return { success: false, error: "Master Sheet nahi mili" };

  var lastRow = master.getLastRow();
  if (lastRow < 2) return { success: true, data: [] };

  var raw = master.getRange(2, 1, lastRow - 1, 7).getValues();
  var rows = [];
  raw.forEach(function(r, idx) {
    if (!r[0] && !r[1]) return;
    var dateVal = r[3];
    rows.push({
      rowIndex:    idx + 2,
      seGof:       r[0].toString(),
      itemCodes:   r[1].toString(),
      itemDescs:   r[2].toString(),
      date:        dateVal instanceof Date ? dateToStr(dateVal) : r[3].toString(),
      boxDescs:    r[4].toString(),
      qtys:        r[5].toString(),
      vendorCodes: r[6].toString()
    });
  });
  return { success: true, data: rows };
}

// ============================================================
// ADD MASTER ROW — duplicate check + alignment
// ============================================================
function addMasterRow(data, userName) {
  var ss        = SpreadsheetApp.openById(SPREADSHEET_ID);
  var master    = ss.getSheetByName("Master Sheet");
  if (!master) return { success: false, error: "Master Sheet nahi mili" };

  // Auto-format on first use
  if (master.getLastRow() < 1 || master.getRange(1,1).getValue() !== "SE GOF #") {
    formatMasterSheet(master);
  }

  // Duplicate check — same SE GOF bilkul bhi accept nahi karna
  var lastRow = master.getLastRow();
  if (lastRow >= 2) {
    var existing = master.getRange(2, 1, lastRow - 1, 7).getValues();
    for (var i = 0; i < existing.length; i++) {
      if (existing[i][0].toString().trim() === data.seGof.trim()) {
        return { success: false, error: "Duplicate entry! SE GOF " + data.seGof + " pehle se maujood hai." };
      }
    }
  }

  var rateSheet = ss.getSheetByName("Rate File");
  var rateData  = rateSheet ? rateSheet.getDataRange().getValues() : [];

  var dateVal  = data.date ? new Date(data.date) : new Date();
  var isSunday = dateVal.getDay() === 0;
  var codes    = data.itemCodes.split('\n').map(function(x){ return x.trim(); }).filter(Boolean);
  var qtys     = (data.qtys || "").split('\n').map(function(x){ return x.trim(); }).filter(Boolean);

  var descs = [], boxDescs = [], vendors = [], newQties = [];
  codes.forEach(function(code, idx) {
    var matchingVendors = [], seen = [];
    for (var i = 1; i < rateData.length; i++) {
      var rCode = rateData[i][0].toString().trim();
      var normalizedR = rCode.toUpperCase().replace(/^HS[-.]?/, '');
      var normalizedC = code.toUpperCase().replace(/^HS[-.]?/, '');
      if (rCode.toUpperCase() === code.toUpperCase() || rCode.toUpperCase().endsWith('-' + code.toUpperCase()) || normalizedR === normalizedC) {
        var vCode = rateData[i][2].toString().trim();
        if (seen.indexOf(vCode) === -1) {
          seen.push(vCode);
          matchingVendors.push({ code: vCode, name: rateData[i][3].toString(), desc: rateData[i][1].toString(), box: rateData[i][5].toString() });
        }
      }
    }
    var qty = Number(qtys[idx]) || 1;
    if (matchingVendors.length === 0) {
      descs.push('NOT FOUND: ' + code); boxDescs.push(''); vendors.push(''); newQties.push(String(qty));
    } else if (matchingVendors.length === 1) {
      descs.push(matchingVendors[0].desc); boxDescs.push(matchingVendors[0].box); vendors.push(matchingVendors[0].code); newQties.push(String(qty));
    } else if (isSunday) {
      var ccp = matchingVendors.find(function(v){ return v.code.toUpperCase() === 'CCP'; }) || matchingVendors[0];
      descs.push(ccp.desc); boxDescs.push(ccp.box); vendors.push(ccp.code); newQties.push(String(qty));
    } else {
      var selected = getNextVendorFromSheet(ss, matchingVendors[0].desc, matchingVendors, master.getLastRow() + 1, dateVal);
      descs.push(selected.desc); boxDescs.push(selected.box); vendors.push(selected.code); newQties.push(String(qty));
    }
  });

  var newRow = [data.seGof, codes.join('\n'), descs.join('\n'), dateToStr(dateVal), boxDescs.join('\n'), newQties.join('\n'), vendors.join('\n')];
  var appendedRow = master.appendRow(newRow);
  SpreadsheetApp.flush();

  // Align the new data row
  var newRowNum = master.getLastRow();
  var dataRange = master.getRange(newRowNum, 1, 1, 7);
  dataRange.setHorizontalAlignment("left");
  dataRange.setVerticalAlignment("top");
  // Center-align: SE GOF (col1), Date (col4), Qty (col6), Vendor (col7)
  master.getRange(newRowNum, 1).setHorizontalAlignment("center");
  master.getRange(newRowNum, 4).setHorizontalAlignment("center");
  master.getRange(newRowNum, 6).setHorizontalAlignment("center");
  master.getRange(newRowNum, 7).setHorizontalAlignment("center");
  // Wrap text for multi-line cells
  master.getRange(newRowNum, 1, 1, 7).setWrap(true);

  writeLog(ss, userName, "ADD ENTRY", "SE GOF: " + data.seGof + " | Items: " + codes.join(', ') + " | Date: " + dateToStr(dateVal));
  return { success: true, message: "Row add ho gayi ✅" };
}

// ============================================================
// UPDATE MASTER ROW
// ============================================================
function updateMasterRow(rowIndex, data, userName) {
  var ss     = SpreadsheetApp.openById(SPREADSHEET_ID);
  var master = ss.getSheetByName("Master Sheet");
  if (!master) return { success: false, error: "Master Sheet nahi mili" };

  var dateVal = data.date ? new Date(data.date) : new Date();
  var dateStr = Utilities.formatDate(dateVal, TZ, "dd-MMM-yyyy");
  master.getRange(rowIndex, 1).setValue(data.seGof);
  master.getRange(rowIndex, 2).setValue(data.itemCodes);
  master.getRange(rowIndex, 3).setValue(data.itemDescs);
  master.getRange(rowIndex, 4).setValue(dateStr);
  master.getRange(rowIndex, 5).setValue(data.boxDescs);
  master.getRange(rowIndex, 6).setValue(data.qtys);
  master.getRange(rowIndex, 7).setValue(data.vendorCodes);

  // Re-align updated row
  var dataRange = master.getRange(rowIndex, 1, 1, 7);
  dataRange.setHorizontalAlignment("left");
  master.getRange(rowIndex, 1).setHorizontalAlignment("center");
  master.getRange(rowIndex, 4).setHorizontalAlignment("center");
  master.getRange(rowIndex, 6).setHorizontalAlignment("center");
  master.getRange(rowIndex, 7).setHorizontalAlignment("center");
  dataRange.setWrap(true);

  SpreadsheetApp.flush();
  writeLog(ss, userName, "EDIT ENTRY", "Row #" + rowIndex + " | SE GOF: " + data.seGof);
  return { success: true, message: "Row update ho gayi ✅" };
}

// ============================================================
// DELETE MASTER ROW
// ============================================================
function deleteMasterRow(rowIndex, userName) {
  var ss     = SpreadsheetApp.openById(SPREADSHEET_ID);
  var master = ss.getSheetByName("Master Sheet");
  if (!master) return { success: false, error: "Master Sheet nahi mili" };

  var rowData = master.getRange(rowIndex, 1, 1, 7).getValues()[0];
  master.deleteRow(rowIndex);
  SpreadsheetApp.flush();

  writeLog(ss, userName, "DELETE ENTRY", "Row #" + rowIndex + " | SE GOF: " + rowData[0] + " | Items: " + rowData[1]);
  return { success: true, message: "Row delete ho gayi ✅" };
}

// ============================================================
// GET ITEM BY CODE
// ============================================================
function getItemByCode(code, dateStr, currentRow) {
  var ss        = SpreadsheetApp.openById(SPREADSHEET_ID);
  var rateSheet = ss.getSheetByName("Rate File");
  if (!rateSheet) return { success: false, error: "Rate File nahi mili" };

  var rateData = rateSheet.getDataRange().getValues();
  var dateVal  = dateStr ? new Date(dateStr) : new Date();
  var isSunday = dateVal.getDay() === 0;
  var codes    = code.split('\n').map(function(x){ return x.trim(); }).filter(Boolean);
  var result   = [];

  codes.forEach(function(c) {
    var matchingVendors = [], seen = [];
    for (var i = 1; i < rateData.length; i++) {
      var rCode = rateData[i][0].toString().trim();
      var normalizedR = rCode.toUpperCase().replace(/^HS[-.]?/, '');
      var normalizedC = c.toUpperCase().replace(/^HS[-.]?/, '');
      if (rCode.toUpperCase() === c.toUpperCase() || rCode.toUpperCase().endsWith('-' + c.toUpperCase()) || normalizedR === normalizedC) {
        var vCode = rateData[i][2].toString().trim();
        if (seen.indexOf(vCode) === -1) {
          seen.push(vCode);
          matchingVendors.push({ code: vCode, name: rateData[i][3].toString(), desc: rateData[i][1].toString(), box: rateData[i][5].toString() });
        }
      }
    }
    if (matchingVendors.length === 0) {
      result.push({ code: c, desc: 'NOT FOUND', box: '', vendor: '' });
    } else if (matchingVendors.length === 1) {
      result.push({ code: c, desc: matchingVendors[0].desc, box: matchingVendors[0].box, vendor: matchingVendors[0].code });
    } else if (isSunday) {
      var ccp = matchingVendors.find(function(v){ return v.code.toUpperCase() === 'CCP'; }) || matchingVendors[0];
      result.push({ code: c, desc: ccp.desc, box: ccp.box, vendor: ccp.code });
    } else {
      var master   = ss.getSheetByName("Master Sheet");
      var selected = getNextVendorFromSheet(ss, matchingVendors[0].desc, matchingVendors, currentRow || 9999, dateVal);
      result.push({ code: c, desc: selected.desc, box: selected.box, vendor: selected.code });
    }
  });

  return { success: true, items: result };
}

// ============================================================
// GET NEXT VENDOR
// ============================================================
function getNextVendorFromSheet(ss, itemDesc, matchingVendors, currentRow, enteredDate) {
  var master  = ss.getSheetByName("Master Sheet");
  var lastRow = master.getLastRow();
  var lastVendorCode = null;

  function normDate(d) {
    if (!(d instanceof Date)) return null;
    return new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
  }
  var targetDate = normDate(enteredDate);

  if (lastRow >= 2 && targetDate) {
    var data = master.getRange(2, 1, lastRow - 1, 7).getValues();
    for (var i = data.length - 1; i >= 0; i--) {
      var rowNum = i + 2;
      if (rowNum === currentRow) continue;
      var rowDate = normDate(data[i][3]);
      if (rowDate !== targetDate) continue;
      var descLines   = data[i][2].toString().split('\n').map(function(x){ return x.trim(); });
      var vendorLines = data[i][6].toString().split('\n').map(function(x){ return x.trim(); });
      for (var j = 0; j < descLines.length; j++) {
        if (descLines[j] === itemDesc && vendorLines[j]) {
          lastVendorCode = vendorLines[j].trim();
          break;
        }
      }
      if (lastVendorCode) break;
    }
  }

  if (!lastVendorCode) return matchingVendors[0];
  var lastIdx = matchingVendors.findIndex(function(v){ return v.code.toUpperCase() === lastVendorCode.toUpperCase(); });
  if (lastIdx === -1) return matchingVendors[0];
  return matchingVendors[(lastIdx + 1) % matchingVendors.length];
}

// ============================================================
// GET RATE FILE
// ============================================================
function getRateFile() {
  var ss   = SpreadsheetApp.openById(SPREADSHEET_ID);
  var rate = ss.getSheetByName("Rate File");
  if (!rate) return { success: false, error: "Rate File nahi mili" };

  var data = rate.getDataRange().getValues();
  var rows = [];
  for (var i = 1; i < data.length; i++) {
    if (!data[i][0]) continue;
    rows.push({
      itemCode:   data[i][0].toString(),
      itemDesc:   data[i][1].toString(),
      vendorCode: data[i][2].toString(),
      vendorName: data[i][3].toString(),
      rate:       data[i][4],
      boxDesc:    data[i][5].toString(),
      gst:        data[i][6]
    });
  }
  return { success: true, data: rows };
}

// ============================================================
// GET VENDOR LIST
// ============================================================
function getVendorList() {
  var ss   = SpreadsheetApp.openById(SPREADSHEET_ID);
  var rate = ss.getSheetByName("Rate File");
  if (!rate) return { success: false, error: "Rate File nahi mili" };

  var data = rate.getDataRange().getValues();
  var vendors = {}, list = [];
  for (var i = 1; i < data.length; i++) {
    var vCode = data[i][2].toString().trim();
    var vName = data[i][3].toString().trim();
    if (vCode && !vendors[vCode]) {
      vendors[vCode] = vName;
      list.push({ code: vCode, name: vName });
    }
  }
  list.sort(function(a,b){ return a.code.localeCompare(b.code); });
  return { success: true, data: list };
}

// ============================================================
// ACTIVITY LOG — GET
// ============================================================
function getActivityLog(dateFrom, dateTo, filterUser) {
  var ss        = SpreadsheetApp.openById(SPREADSHEET_ID);
  var logSheet  = ss.getSheetByName(LOG_SHEET_NAME);
  if (!logSheet) return { success: true, data: [] };

  var lastRow = logSheet.getLastRow();
  if (lastRow < 2) return { success: true, data: [] };

  var raw  = logSheet.getRange(2, 1, lastRow - 1, 5).getValues();
  var from = dateFrom ? new Date(dateFrom) : null;
  var to   = dateTo   ? new Date(dateTo + "T23:59:59") : null;

  var rows = [];
  raw.forEach(function(r) {
    var rowTime = new Date(r[0]);
    if (from && rowTime < from) return;
    if (to   && rowTime > to)   return;
    if (filterUser && r[1].toString().toLowerCase().indexOf(filterUser.toLowerCase()) === -1) return;
    rows.push({
      time:    r[0].toString(),
      user:    r[1].toString(),
      action:  r[2].toString(),
      detail:  r[3].toString(),
      session: r[4].toString()
    });
  });

  rows.reverse();
  return { success: true, data: rows };
}

// ============================================================
// GENERATE SUMMARY DATA
// ============================================================
function generateSummaryData(vendorCode, dateFrom, dateTo) {
  var ss       = SpreadsheetApp.openById(SPREADSHEET_ID);
  var master   = ss.getSheetByName("Master Sheet");
  var rateFile = ss.getSheetByName("Rate File");
  if (!master || !rateFile) return { success: false, error: "Sheet nahi mili" };

  var rateData = rateFile.getDataRange().getValues();
  var rateMap  = {}, vendorName = "";
  for (var i = 1; i < rateData.length; i++) {
    var desc = rateData[i][1], vc = rateData[i][2];
    rateMap[vc + "_" + desc] = { rate: Number(rateData[i][4])||0, gst: Number(rateData[i][6])||0 };
    if (vc === vendorCode && !vendorName) vendorName = rateData[i][3].toString();
  }

  var from = normalizeDate(dateFrom ? new Date(dateFrom) : null);
  var to   = normalizeDate(dateTo   ? new Date(dateTo)   : null);

  var lastRow = master.getLastRow();
  if (lastRow < 2) return { success: false, error: "Master Sheet mein data nahi" };
  var raw = master.getRange(2, 1, lastRow - 1, 7).getValues();

  var grouped = {};
  raw.forEach(function(r) {
    var rowDate = normalizeDate(r[3]);
    if (!rowDate) return;
    if (from && rowDate < from) return;
    if (to   && rowDate > to)   return;
    var descs   = r[2].toString().split('\n').map(function(x){ return x.trim(); }).filter(Boolean);
    var qtys    = r[5].toString().split('\n').map(function(x){ return x.trim(); }).filter(Boolean);
    var vendors = r[6].toString().split('\n').map(function(x){ return x.trim(); }).filter(Boolean);
    descs.forEach(function(desc, idx) {
      if (vendorCode && vendors[idx] !== vendorCode) return;
      grouped[desc] = (grouped[desc] || 0) + (Number(qtys[idx]) || 0);
    });
  });

  var rows = [], totalQty = 0, grandTotal = 0;
  for (var d in grouped) {
    var qty    = grouped[d];
    var info   = rateMap[vendorCode + "_" + d] || { rate: 0, gst: 0 };
    var amount = Math.round(info.rate * qty);
    var gstAmt = Math.round(info.gst  * qty);
    var total  = amount + gstAmt;
    rows.push({ desc: d, qty: qty, amount: amount, gst: gstAmt, total: total });
    totalQty   += qty;
    grandTotal += total;
  }

  return { success: true, vendorName: vendorName, rows: rows, totalQty: totalQty, grandTotal: grandTotal };
}

// ============================================================
// GENERATE VENDOR SLIP DATA
// ============================================================
function generateVendorSlipData(vendorCode, dateFrom, dateTo) {
  var ss       = SpreadsheetApp.openById(SPREADSHEET_ID);
  var master   = ss.getSheetByName("Master Sheet");
  var rateFile = ss.getSheetByName("Rate File");
  if (!master || !rateFile) return { success: false, error: "Sheet nahi mili" };

  var rateData = rateFile.getDataRange().getValues();
  var rateMap  = {}, vendorName = "";
  for (var i = 1; i < rateData.length; i++) {
    var desc = rateData[i][1], vc = rateData[i][2];
    rateMap[vc + "_" + desc] = { rate: Number(rateData[i][4])||0, gstUnit: Number(rateData[i][6])||0 };
    if (vc === vendorCode && !vendorName) vendorName = rateData[i][3].toString();
  }

  var from = normalizeDate(dateFrom ? new Date(dateFrom) : null);
  var to   = normalizeDate(dateTo   ? new Date(dateTo)   : null);

  var lastRow = master.getLastRow();
  if (lastRow < 2) return { success: false, error: "Master Sheet mein data nahi" };
  var raw = master.getRange(2, 1, lastRow - 1, 7).getValues();

  var expanded = [];
  raw.forEach(function(r) {
    var rowDate = normalizeDate(r[3]);
    if (!rowDate) return;
    if (from && rowDate < from) return;
    if (to   && rowDate > to)   return;
    var codes   = r[1].toString().split('\n').map(function(x){ return x.trim(); }).filter(Boolean);
    var descs   = r[2].toString().split('\n').map(function(x){ return x.trim(); }).filter(Boolean);
    var qtys    = r[5].toString().split('\n').map(function(x){ return x.trim(); }).filter(Boolean);
    var vendors = r[6].toString().split('\n').map(function(x){ return x.trim(); }).filter(Boolean);
    codes.forEach(function(code, idx) {
      if (vendorCode && vendors[idx] !== vendorCode) return;
      expanded.push({ seGof: r[0].toString(), itemCode: code, itemDesc: descs[idx]||'', qty: Number(qtys[idx])||1, vCode: vendors[idx]||'' });
    });
  });

  if (expanded.length === 0) return { success: false, error: "Koi data nahi mila" };

  expanded.sort(function(a,b){
    if (a.vCode < b.vCode) return -1; if (a.vCode > b.vCode) return 1;
    if (a.itemDesc < b.itemDesc) return -1; if (a.itemDesc > b.itemDesc) return 1;
    return 0;
  });

  var sections = [];
  var currentVendor = null, currentDesc = null, currentSection = null, currentGroup = null;
  var grandQty = 0, grandAmt = 0, grandGst = 0, grandTotal = 0;

  expanded.forEach(function(r) {
    if (r.vCode !== currentVendor) {
      if (currentGroup)   currentSection.groups.push(currentGroup);
      if (currentSection) sections.push(currentSection);
      currentVendor  = r.vCode;
      currentDesc    = null;
      currentGroup   = null;
      currentSection = { vendor: r.vCode, groups: [], totalQty: 0, totalAmt: 0 };
    }
    if (r.itemDesc !== currentDesc) {
      if (currentGroup) currentSection.groups.push(currentGroup);
      currentDesc  = r.itemDesc;
      currentGroup = { desc: r.itemDesc, rows: [], totalQty: 0, totalAmt: 0, totalGst: 0, total: 0 };
    }
    var info        = rateMap[r.vCode + "_" + r.itemDesc] || { rate: 0, gstUnit: 0 };
    var amount      = Math.round(info.rate * r.qty);
    var gstAmount   = Math.round(info.gstUnit * r.qty);
    var totalAmount = amount + gstAmount;
    currentGroup.rows.push({ seGof: r.seGof, itemCode: r.itemCode, qty: r.qty, amount: amount, gst: gstAmount, total: totalAmount });
    currentGroup.totalQty += r.qty; currentGroup.totalAmt += amount; currentGroup.totalGst += gstAmount; currentGroup.total += totalAmount;
    currentSection.totalQty += r.qty; currentSection.totalAmt += totalAmount;
    grandQty += r.qty; grandAmt += amount; grandGst += gstAmount; grandTotal += totalAmount;
  });

  if (currentGroup)   currentSection.groups.push(currentGroup);
  if (currentSection) sections.push(currentSection);

  return { success: true, vendorName: vendorName, sections: sections, grandQty: grandQty, grandAmt: grandAmt, grandGst: grandGst, grandTotal: grandTotal };
}

// ============================================================
// GENERATE VENDOR DETAILS DATA
// ============================================================
function generateVendorDetailsData(dateFrom, dateTo) {
  var ss       = SpreadsheetApp.openById(SPREADSHEET_ID);
  var master   = ss.getSheetByName("Master Sheet");
  var rateFile = ss.getSheetByName("Rate File");
  if (!master || !rateFile) return { success: false, error: "Sheet nahi mili" };

  var rateData = rateFile.getDataRange().getValues();
  var vendorNameMap = {};
  for (var i = 1; i < rateData.length; i++) {
    var vc = rateData[i][2].toString().trim(), vn = rateData[i][3].toString().trim();
    if (vc && vn && !vendorNameMap[vc]) vendorNameMap[vc] = vn;
  }

  var from = normalizeDate(dateFrom ? new Date(dateFrom) : null);
  var to   = normalizeDate(dateTo   ? new Date(dateTo)   : null);
  if (!from || !to) return { success: false, error: "Date From aur Date To dono zaroori hain" };

  var lastRow = master.getLastRow();
  if (lastRow < 2) return { success: false, error: "Master Sheet mein data nahi" };
  var raw = master.getRange(2, 1, lastRow - 1, 7).getValues();

  var unique = {};
  raw.forEach(function(r) {
    var rowDate = normalizeDate(r[3]);
    if (!rowDate || rowDate < from || rowDate > to) return;
    r[6].toString().split('\n').forEach(function(vc) {
      vc = vc.trim();
      if (vc) unique[vc] = true;
    });
  });

  var list = Object.keys(unique).sort().map(function(vc){ return { code: vc, name: vendorNameMap[vc] || "—" }; });
  return { success: true, data: list, total: list.length };
}

// ============================================================
// GENERATE REQUISITION DATA
// ============================================================
function generateRequisitionData(vendorCode, dateFrom, dateTo) {
  var ss     = SpreadsheetApp.openById(SPREADSHEET_ID);
  var master = ss.getSheetByName("Master Sheet");
  if (!master) return { success: false, error: "Master Sheet nahi mili" };

  var from = normalizeDate(dateFrom ? new Date(dateFrom) : null);
  var to   = normalizeDate(dateTo   ? new Date(dateTo)   : null);

  var lastRow = master.getLastRow();
  if (lastRow < 2) return { success: false, error: "Master Sheet mein data nahi" };
  var raw = master.getRange(2, 1, lastRow - 1, 7).getValues();

  var expanded = [];
  raw.forEach(function(r) {
    var rowDate = normalizeDate(r[3]);
    if (!rowDate) return;
    if (from && rowDate < from) return;
    if (to   && rowDate > to)   return;
    var codes   = r[1].toString().split('\n').map(function(x){ return x.trim(); }).filter(Boolean);
    var descs   = r[2].toString().split('\n').map(function(x){ return x.trim(); }).filter(Boolean);
    var boxes   = r[4].toString().split('\n').map(function(x){ return x.trim(); }).filter(Boolean);
    var qtys    = r[5].toString().split('\n').map(function(x){ return x.trim(); }).filter(Boolean);
    var vendors = r[6].toString().split('\n').map(function(x){ return x.trim(); }).filter(Boolean);
    codes.forEach(function(code, idx) {
      if (vendorCode && vendors[idx] !== vendorCode) return;
      expanded.push({ seGof: r[0].toString(), itemCode: code, itemDesc: descs[idx]||'', boxDesc: boxes[idx]||'', qty: Number(qtys[idx])||1, vCode: vendors[idx]||'' });
    });
  });

  if (expanded.length === 0) return { success: false, error: "Koi data nahi mila" };

  expanded.sort(function(a,b){
    if (a.vCode < b.vCode) return -1; if (a.vCode > b.vCode) return 1;
    if (a.itemDesc < b.itemDesc) return -1; if (a.itemDesc > b.itemDesc) return 1;
    return 0;
  });

  var sections = [];
  var currentVendor = null, currentDesc = null, currentSection = null, currentGroup = null;

  expanded.forEach(function(r) {
    if (r.vCode !== currentVendor) {
      if (currentGroup)   currentSection.groups.push(currentGroup);
      if (currentSection) sections.push(currentSection);
      currentVendor  = r.vCode;
      currentDesc    = null;
      currentGroup   = null;
      currentSection = { vendor: r.vCode, groups: [], totalQty: 0 };
    }
    if (r.itemDesc !== currentDesc) {
      if (currentGroup) currentSection.groups.push(currentGroup);
      currentDesc  = r.itemDesc;
      currentGroup = { desc: r.itemDesc, rows: [], totalQty: 0 };
    }
    currentGroup.rows.push({ seGof: r.seGof, itemCode: r.itemCode, boxDesc: r.boxDesc, qty: r.qty });
    currentGroup.totalQty   += r.qty;
    currentSection.totalQty += r.qty;
  });
  if (currentGroup)   currentSection.groups.push(currentGroup);
  if (currentSection) sections.push(currentSection);

  return { success: true, sections: sections };
}
